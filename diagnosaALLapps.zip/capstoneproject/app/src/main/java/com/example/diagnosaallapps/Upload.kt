package com.example.diagnosaallapps

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Upload : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upload)
    }
}